var express =  require('express');
var router = express.Router();
var DButilsAzure = require('../DButils');
var jwt = require('jsonwebtoken');
const superSecret = new Buffer("ShaharToken","Base64"); 
var bodyParser = require('body-parser');
var router = express.Router();

router.use('/', function(req,res,next){
    console.log(req.body);
    console.log("REQ TEST RINA: " + req.headers['x-access-token']);
    var token=req.body.token || req.query.token || req.headers['x-access-token'] ;
    if (token) {
       jwt.verify(token, superSecret, function (err, decoded) {
       if (err) {
           return res.json({ success: false, message: 'Invalid token!' });
       } else {
           var decoded = jwt.decode(token, {complete: true});
           req.decoded = decoded; // decoded.payload , decoded.header
           console.log("REDIRECTING use");
           next();
       }
   })}
    else{
        console.log("ERROR entered");
       res.send("missing token");
       res.end();
    }
});

//11
router.get('/GetFavoritePOI', function(req,res){
    var token=req.headers['x-access-token'];
    var decoded=jwt.decode(token, {complete:true});   
	let UserName=decoded.payload.UserName;
	DButilsAzure.execQuery("SELECT * FROM UserAttractions where UserName='"+UserName+"';")
				.then(function(result){
				    //console.log(result[0]['idPOI']);
					res.send(result);
			})
			.catch(function(err){
                console.log("RINA"+err);
				res.send({ message: "rows didn't came back"})
				
			})
});

//12
router.post('/addToUserFavoritePOI', function(req,res){
	var token = req.body.token;
    var idPOI = req.body.idPOI;
    var decoded = jwt.decode(token, {complete:true});
	let UserName = decoded.payload.UserName;
    console.log("IN Server Req: "+UserName);
	DButilsAzure.execQuery("INSERT INTO UserAttractions(UserName,idPOI) VALUES('"+UserName+"','"+idPOI+"');")
				.then(function(result){
				res.send({ message: "POI added successfully"})

			})
			.catch(function(err){
				res.send({ message: "rows didn't came back"})
				
			})
});

//15
router.delete('/deleteFromSaved', function(req,res){

	var token = req.body.token;
	var idPOI=req.body.idPOI;
    var decoded=jwt.decode(token, {complete:true});   
	let UserName=decoded.payload.UserName;
	console.log(UserName);
	console.log(idPOI);
    console.log(token);

	DButilsAzure.execQuery("DELETE from UserAttractions where idPOI='"+req.body.idPOI+"' AND UserName='"+UserName+"';")
				.then(function(result){
				res.send({ message: "POI delete successfully"})

			})
			.catch(function(err){
				res.send({ message: "rows didn't came back"})
				
			})
});

//16
router.post('/addNewReview',function(req,res){
	var token = req.body.token;
	var idPOI=req.body.idPOI;
	var reviews= req.body.reviews;
    var decoded=jwt.decode(token, {complete:true});  
	let UserName=decoded.payload.UserName;
	DButilsAzure.execQuery("INSERT INTO Reviews(idPOI,reviews) VALUES('"+req.body.idPOI+"','"+req.body.reviews+"');")
				.then(function(result){
				res.send({ message: "review added successfully"})

			})
			.catch(function(err){
				res.send({ message: "add review fail"})
				
			})
});

// NEW:
router.put('/deleteAllFavorites', function(req,res){
    console.log("Deleting all pois to update...");
    var token = req.body.token;
    console.log(token);
    var decoded = jwt.decode(token, {complete:true});
    let UserName = decoded.payload.UserName;
    console.log(UserName);
    console.log(token);

    DButilsAzure.execQuery("DELETE from UserAttractions where UserName='"+UserName+"';")
        .then(function(result){
            res.send({ message: "POI delete successfully"})

        })
        .catch(function(err){
            res.send({ message: "rows didn't came back"})

        })
});

router.get('/GetFavoriteCategories', function(req,res){
    console.log("getting fav categories...");

    var token=req.headers['x-access-token'];
    var decoded=jwt.decode(token, {complete:true});
    let UserName=decoded.payload.UserName;
    DButilsAzure.execQuery("SELECT Category1, Category2 FROM users where UserName='"+UserName+"';")
        .then(function(result){
            console.log(result);
            res.send(result);
        })
        .catch(function(err){
            console.log("RINA"+err);
            res.send({ message: "rows didn't came back"})

        })
});

module.exports=router;