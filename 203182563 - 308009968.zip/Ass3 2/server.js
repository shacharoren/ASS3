//Server class - responsible about initiate connections
var express = require('express');
var bodyParser = require('body-parser');
var app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
var util = require('util')
var cors = require('cors');
app.use(cors());
var DButilsAzure = require('./DButils');
var jwt = require('jsonwebtoken');

var users = require('./routes/users');
var data = require('./routes/data');
var auto = require('./routes/auto');

var port = 3000;
var server = app.listen(port, function () {
    var host = server.address().address;
    var port = server.address().port;
    console.log("Example app listening at http://%s:%s",host, port);
    });

app.use('/users',users)
app.use('/data',data)
app.use('/auto',auto)
app.use(express.static(__dirname + '/public/app'));