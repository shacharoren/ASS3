

let tripAdviserApp = angular.module("tripAdviserApp", ["ngRoute"]);

tripAdviserApp.config(['$locationProvider', '$routeProvider', function($locationProvider, $routeProvider)  {
    $locationProvider.hashPrefix('');

    $routeProvider
    .when('/', {
        templateUrl: '../components/Home/home-view.html',
        controller : 'HomeController'
    })
    .when('/login', {
        templateUrl: '../components/Login/login-view.html',
        controller : 'LoginController'
    })
    .when('/poi', {
        templateUrl: '../components/POI/poi-view.html',
        controller: 'PoiController'
    })
    .when('/about', {
        templateUrl: '../components/About/about-view.html',
    })
    .when('/favorites', {
        templateUrl: '../components/Favorites/favorites-view.html',
        controller: 'FavoritesController'
    })
    .when('/favorites/successfulSave', {
        templateUrl: '../components/Favorites/successfulSave-view.html',
    })
    .when('/register', {
        templateUrl: '../components/Register/register-view.html',
        controller: 'RegisterController'
    })
    .when('/restore', {
        templateUrl: '../components/Restore/restore-view.html',
        controller: 'RestoreController'
    })
    .when('/register/successfulRegistration', {
        templateUrl: '../components/Register/successfulRegistration-view.html'
    })
    .when('/signin', {
        templateUrl: '../components/Login/login-view.html'
    })
    .when('/poiInfo/:id', {
        templateUrl: '../components/POIInfo/poiInfo-view.html',
        controller : 'POIInfoController'
    })
    //.otherwise({ redirectTo: '/' });
}]);


