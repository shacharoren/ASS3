(function() {
    'use strict';

    tripAdviserApp.controller('POIInfoController', POIInfoController);

    POIInfoController.$inject = ['$scope', '$location', '$http', '$window', 'PoiService'];

    function POIInfoController($scope, $location, $http, $window, PoiService) {

        let serverURL = 'http://localhost:3000/';
        let chosenPoiId = document.URL.split('/')[5];

        $scope.chosenPoi = undefined;
        $scope.chosenPoiViews = undefined;
        $scope.chosenPoiDescription = undefined;

        let allPois = PoiService.getAllPois();

        let chosenPoiIdInfo={
            "idPOI": chosenPoiId
        }

        if(allPois.length == 0) {
            pollData();
        }else {
            findPoi();
        }

        // get current number of views
        $http.get(serverURL + "data/GetNumberOfViewsPOI/" + chosenPoiId)
            .then(function (response){
                $scope.chosenPoiViews = response.data[0]["views"];
                console.log($scope.chosenPoiViews);
            }, function (response) {
                console.log("fail GET");
            })

        // get poi description
        $http.get(serverURL + "data/getDescriptionPOI/" + chosenPoiId)
            .then(function (response){
                $scope.chosenPoiDescription = response.data[0]["Description"];
                console.log($scope.chosenPoiDescription);
            }, function (response) {
                console.log("fail GET");
            })

        function pollData() {
            let tempPois = PoiService.getAllPois();
            if(tempPois.length == 0) {
                setTimeout(function() {
                    pollData();
                }, 2000)
            } else {
                $scope.animate = false;
                allPois = tempPois;
                findPoi();
                $scope.$apply();
            }
        }

        function findPoi(){
            for(var i = 0; i < allPois.length; i++){
                if(allPois[i].idPOI == chosenPoiId){
                    $scope.chosenPoi = allPois[i];
                }
            }
        }

        // increase number of view for the watched poi
        $http.put(serverURL + "data/SetNumberOfViewsPOI/",chosenPoiIdInfo)
            .then(function (response){
                console.log("success2");
            }, function (response) {
                console.log("fail PUT");
            })

        ////////// add/remove favorites

        $scope.addToFavorites = function (idPOI){
            let tmp = $window.localStorage.getItem("favorites");

            let favoritesInLocalStorage = tmp.split(",");

            for(let i = 0; i < allPois.length; i++){
                if(allPois[i].idPOI == idPOI){
                    allPois[i].inFev = true;
                }
            }
            if(!contains(favoritesInLocalStorage, idPOI))
            {
                favoritesInLocalStorage.push(idPOI.toString());
                console.log(favoritesInLocalStorage);
                $window.localStorage.setItem("favorites", favoritesInLocalStorage);
            }
        }

        $scope.removeFromFavorites = function(idPOI){
            console.log("in remove");

            for(let i = 0; i < allPois.length; i++){
                if(allPois[i].idPOI == idPOI){
                    allPois[i].inFev = false;
                }
            }

            let tmp = $window.localStorage.getItem("favorites");
            let favoritesInLocalStorage = tmp.split(",");

            var index = favoritesInLocalStorage.indexOf(idPOI.toString());
            console.log("removing: "+index);
            if (index > -1) {
                favoritesInLocalStorage.splice(index, 1);
            }

            $window.localStorage.setItem("favorites", favoritesInLocalStorage);
            console.log(favoritesInLocalStorage);
        };

        function contains(a, obj) {
            var i = a.length;
            while (i--) {
                if (a[i] == obj) {
                    return true;
                }
            }
            return false;
        }
    }

})();