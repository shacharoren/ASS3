(function() {
    'use strict';

    tripAdviserApp.controller('HomeController', HomeController);

    HomeController.$inject = ['$scope', '$http', '$location', '$window', 'PoiService'];

    function HomeController($scope, $http, $location, $window, PoiService) {

        let serverURL = 'http://localhost:3000/';

        $scope.animate = true;
        $scope.randomPois = PoiService.getThreeRandoms();

        let username = $window.localStorage.getItem("username");
        $scope.saved = $window.localStorage.getItem("login") == 'true' ? $window.localStorage.getItem("favorites"+username).split(",") : undefined;
        $scope.recentleySaved = PoiService.getRecentlySaved();

        $scope.recent1 = undefined;
        $scope.recent2 = undefined;
        $scope.recent3 = undefined;

        $scope.popular1 = undefined;
        $scope.popular2 = undefined;

        $scope.cat1 = $window.localStorage.getItem("Category1"+username);
        $scope.cat2 = $window.localStorage.getItem("Category2"+username);

        if($scope.randomPois.length == 0) {
            pollData();
        }

        $scope.getPoiInfo = function(id)
        {
            $location.path('/poiInfo/'+id);
            $location.replace();
        }

        function pollData() {
            var tempPois = PoiService.getThreeRandoms();
            if(tempPois.length == 0) {
                setTimeout(function() {
                    pollData();
                }, 2000)
            } else {
                $scope.animate = false;
                $scope.randomPois = tempPois;
                $scope.$apply();
            }
        }

        function getPoiInfo(){
            if($scope.saved != undefined && $scope.saved.length-1 > 0){
                $http.get(serverURL + "data/getPOI/"+$scope.saved[$scope.saved.length-1])
                    .then(function (response){
                        $scope.recent1 = response.data[0];
                    }, function (response) {
                        console.log("fail GET");
                    })
            }

            if($scope.saved != undefined && $scope.saved.length-2 > 0){
                $http.get(serverURL + "data/getPOI/"+$scope.saved[$scope.saved.length-2])
                    .then(function (response){
                        $scope.recent2 = response.data[0];
                    }, function (response) {
                        console.log("fail GET");
                    })
            }

            if($scope.saved != undefined && $scope.saved.length-3 > 0){
                $http.get(serverURL + "data/getPOI/"+$scope.saved[$scope.saved.length-3])
                    .then(function (response){
                        $scope.recent3 = response.data[0];
                    }, function (response) {
                        console.log("fail GET");
                    })
            }
        }

        getPoiInfo();

        function getPopoular(){
            console.log($scope.cat1);
            $http.get(serverURL + "data/GetPopularPOIInCat/"+ $scope.cat1)
                .then(function (response){
                    $scope.popular1 = response.data[0];
                }, function (response) {
                    console.log("fail GET");
                });

            $http.get(serverURL + "data/GetPopularPOIInCat/"+ $scope.cat2)
                .then(function (response){
                    $scope.popular2 = response.data[0];
                }, function (response) {
                    console.log("fail GET");
                });
        }

        getPopoular();
    }

})();

