(function() {
    'use strict';

    tripAdviserApp.controller('LoginController', LoginController);

    LoginController.$inject = ['$scope', '$window', 'UtilsService'];

    function LoginController($scope, $window, UtilsService) {
        let serverURL = 'http://localhost:3000/';

        $scope.username = '';
        $scope.password = '';
        $scope.answer1 = '';
        $scope.answer2 = '';

        $scope.login = UtilsService.isLogin();
        $scope.register = false;
        $scope.restore = false;

        $scope.welcome = getWelcome();

        function getWelcome(){
            if(UtilsService.getUsername() == "undefined"){
                return "guest";
            }else{
                return UtilsService.getUsername();
            }
        }

        $scope.getNumOfFav = function(){
            if($scope.login){
                if($window.localStorage.getItem("favorites" + UtilsService.getUsername()) == null){
                    $window.localStorage.setItem("favorites" + UtilsService.getUsername(), undefined);
                }

                let arr = $window.localStorage.getItem("favorites" + UtilsService.getUsername()).split(",");
                let ans = 0;
                for(let i = 0; i < arr.length; i++){
                    if(arr[i] != '' && arr[i] != 'undefined'){
                        ans = ans + 1;
                    }
                }

                return ans;
            }
        }

        $scope.logoutFunction = function() {
            $scope.login = false;
            $scope.welcome = "guest";
            $scope.username = "username";
            UtilsService.setToken('');
            UtilsService.setLogin(false);
            UtilsService.setUsername(undefined);
        }


        $scope.loginFunction = function() {
            UtilsService.loginFunction($scope.username, $scope.password)
                .then(function(results) {
                    // succesfull login
                    console.log("Welcome To TripAdvisor!");
                    console.log(results["data"]["success"]);

                    if(results["data"]["success"] == true){
                        console.log("Hello again! your token is: "+results.data['token']);
                        $scope.login = true;
                        $scope.welcome = $scope.username;
                        UtilsService.setToken(results.data['token']);
                        UtilsService.setLogin(true);
                        UtilsService.setUsername($scope.username);
                    }
                })
                .catch(function(err) {
                    console.log(err);
                });
        }

        $scope.startSignUp = function() {
            $scope.login = false;
            $scope.register = true;
            $scope.restore = false;
        }

        $scope.startRestore = function() {
            $scope.restore = true;
            $scope.login = false;
            $scope.register = false;
        }
    }
})();