(function() {
    'use strict';

    tripAdviserApp.controller('FavoritesController', FavoritesController);

    FavoritesController.$inject = ['$scope', '$http', '$window','UtilsService'];

    function FavoritesController($scope, $http, $window, UtilsService) {
        let serverURL = 'http://localhost:3000/';
        $scope.favorites = UtilsService.getFavorites(); // ids
        $scope.allPois = UtilsService.getAllPois();
        $scope.favoritePois = []; // actual objects of POIs

        if($window.localStorage.getItem("favorites" + UtilsService.getUsername()) == null){
            $window.localStorage.setItem("favorites" + UtilsService.getUsername(),  $scope.favorites);
        }

        $scope.updateFavorites = function(){
            console.log("updating favorites...");
            let tempFavorites = $window.localStorage.getItem("favorites" + UtilsService.getUsername()).split(",");
            if($window.localStorage.getItem("favorites" + UtilsService.getUsername()) == null)
            {
                $window.localStorage.setItem("favorites" + UtilsService.getUsername(), $scope.favorites);
            }


        };

//$scope.favorites.length == 0 ||
        if($scope.allPois.length == 0) {
            pollFavorites();
        } else {
            pullPOIsById();
        }

        function pullPOIsById() {
            $scope.updateFavorites();
            console.log( $scope.favorites)
            let tempFavorites = $window.localStorage.getItem("favorites" + UtilsService.getUsername()).split(",");
            for(var i = 0; i < tempFavorites.length; i++) {
                for(var j = 0; j < $scope.allPois.length; j++) {
                    if($scope.allPois[j]['idPOI'] == tempFavorites[i]){
                        //console.log($scope.allPois[j])
                        $scope.favoritePois.push($scope.allPois[j]);
                    }
                }
            }
        }

        function pollFavorites() {
            let tempPois = UtilsService.getFavorites();
            let tempPois1 = UtilsService.getAllPois();
            if(tempPois == undefined|| tempPois1.length == 0) {
                setTimeout(function() {
                    pollFavorites();
                }, 2000)
            } else {
                $scope.animate = false;
                $scope.favorites = tempPois;
                $scope.allPois = tempPois1;
                pullPOIsById();
                $scope.$apply();
            }
        }

        function contains(a, obj) {
            var i = a.length;
            while (i--) {
                if (a[i] == obj) {
                    return true;
                }
            }
            return false;
        }

        $scope.saveFavorites = function(){
            let data = {
                token: UtilsService.getToken()
            };

            var url = 'http://localhost:3000/auto/deleteAllFavorites';

            $http.put(url,data)
                .then(function (response){
                    // success
                    console.log("sending all favorites to server...");
                    let tmp = $window.localStorage.getItem("favorites" + UtilsService.getUsername()).split(",");
                    console.log("Rina 1");
                    for(var i = 0; i < tmp.length; i++){
                        if(tmp[i] != ""){
                            let idPOI = tmp[i];
                            console.log("Rina 2: " +idPOI);
                            var favoritesObject = {
                                token : UtilsService.getToken(),
                                idPOI : idPOI
                            };

                            let ans = $http({
                                method: 'POST',
                                url: 'http://localhost:3000/auto/addToUserFavoritePOI',
                                data: favoritesObject
                            });

                            console.log("saved: " + idPOI + ", got response: " + ans);
                        }
                    }
                }, function (response) {
                });
            // empty local storage's favorites
            //$window.localStorage.setItem("favorites", "");
        }
    }

})();