(function() {
    'use strict';

    tripAdviserApp.controller('RegisterController', RegisterController);

    RegisterController.$inject = ['$scope', '$http'];

    function RegisterController($scope, $http) {
        let serverURL = 'http://localhost:3000/';
        $scope.requiredError = "please fill in missing fields";
        $scope.firstName = '';
        $scope.lastName = '';
        $scope.city = '';
        $scope.country = '';
        $scope.email = '';
        $scope.username = '';
        $scope.password = '';
        $scope.firstChosenCategory = '';
        $scope.secondChosenCategory = '';
        $scope.answer1 = '';
        $scope.answer2 = '';

        $scope.categories = [];
        $scope.countries = [];

        console.log($scope.countries);

        $scope.register = function(){
            console.log("sent data to register...");
            var registerObject = {
                FirstName: $scope.firstName,
                LastName: $scope.lastName,
                City: $scope.city,
                Country: $scope.country,
                Email: $scope.email,
                Category1: $scope.firstChosenCategory,
                Category2: $scope.secondChosenCategory,
                Answer1: $scope.answer1,
                Answer2: $scope.answer2,
                UserName: $scope.username,
                Password: $scope.password
            };

            let ans = $http({
                method: 'POST',
                url: 'http://localhost:3000/users/register',
                data: registerObject
            });

            console.log(ans);
        }

        // get all categories
        $http.get(serverURL + "data/getAllCategories")
            .then(function (response){
                for(var i = 0; i < response.data.length; i++){
                    $scope.categories.push(response.data[i]['Category']);
                }
                //console.log($scope.categories);
            }, function (response) {
                console.log("fail GET");
            })

        // get all countries
        $http.get(serverURL + "data/getAllCountries")
            .then(function (response){
                console.log(response.data);
                for(var i = 0; i < response.data.length; i++){
                    $scope.countries.push(response.data[i]['name']);
                }
            }, function (response) {
                console.log("fail GET");
            })
    }

})();