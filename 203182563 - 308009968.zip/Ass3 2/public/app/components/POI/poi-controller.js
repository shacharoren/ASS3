(function() {
  'use strict';

  tripAdviserApp.controller('PoiController', PoiController);

  PoiController.$inject = ['$scope', '$http', '$location', '$window', 'PoiService'];

  function PoiController($scope, $http, $location, $window, PoiService) {

      let serverURL = 'http://localhost:3000/';

      $scope.poiDictionary = {
      'Restaurants' : [],
      'Architectural Buildings' : [],
      'Day Trips': [],
      'Nightlife': [],
      'Bike Tours': []
    };

    $scope.chosenCategory = $window.localStorage.getItem("chosenCategory");
    $scope.categories = [];
    $scope.chosenDict = $scope.poiDictionary[$window.localStorage.getItem("chosenCategory")];
    let username = $window.localStorage.getItem("username");
    $scope.sortBy = $window.localStorage.getItem("sortBy"+username);

    $scope.updateSort = function(){
         $window.localStorage.setItem("sortBy"+username, $scope.sortBy);
         if($scope.sortBy == 'rate' || $scope.sortBy == 'default'){
             $window.localStorage.setItem("chosenCategory"+username, undefined);
         }
    };

    $scope.pois = PoiService.getAllPois();

    /////////// Get All POIs ///////////

    if($scope.pois.length == 0) {
        pollData();
    } else {
      categorized($scope.pois);
    }

    $scope.getPoiInfo = function(id)
    {
      $location.path('/poiInfo/'+id);
      $location.replace();
    }

    function pollData() {
        var tempPois = PoiService.getAllPois();
        //console.log(tempPois);
        if(tempPois.length == 0) {
            setTimeout(function() {
                pollData();
            }, 2000)
        } else {
            $scope.pois = tempPois;
            categorized($scope.pois);
            $scope.$apply();
        }
    }

    $scope.getCategories = function(){
        // get all categories
        $http.get(serverURL + "data/getAllCategories")
            .then(function (response){
                for(var i = 0; i < response.data.length; i++){
                    $scope.categories.push(response.data[i]['Category']);
                }
                //console.log($scope.categories);
            }, function (response) {
                console.log("fail GET");
            })
    };

    $scope.getCategories();

  $scope.getDict = function(){
      let a = $scope.chosenCategory.split(' ')[0];
      let b = $scope.chosenCategory.split(' ')[1];

      let c = a + (b != '' ? ' ' + b : b);

      $scope.chosenDict = $scope.poiDictionary[c];
      $window.localStorage.setItem("chosenCategory"+username, $scope.chosenDict[0]['Category']);
      console.log($window.localStorage.getItem("chosenCategory"+username));
      console.log($scope.poiDictionary[$window.localStorage.getItem("chosenCategory"+username)]);
  };

      /*
    $scope.initiatePoiDictionary = function(){
        for(let i = 0; i < $scope.categories.length; i++){
            $scope.poiDictionary.push({
                key:   $scope.categories[i],
                value: []
            });
        }
    };

    $scope.initiatePoiDictionary();
*/
    function categorized(allPois) {
      for(var i = 0 ; i < allPois.length; i++) {
        //console.log(allPois[i]);
        $scope.poiDictionary[allPois[i].Category].push(allPois[i]);
      }
    }

    /////////// Favorties ///////////

    $scope.addToFavorites = function (idPOI){
        let tmp = $window.localStorage.getItem("favorites" + username);
        let favoritesInLocalStorage = tmp.split(",");
        for(let i = 0; i < $scope.pois.length; i++){
            if($scope.pois[i].idPOI == idPOI){
                $scope.pois[i].inFev = true;
            }
        }
        if(!contains(favoritesInLocalStorage, idPOI))
        {
            favoritesInLocalStorage.push(idPOI.toString());
            console.log(favoritesInLocalStorage);
            $window.localStorage.setItem("favorites" + username, favoritesInLocalStorage);
        }
    }

    $scope.removeFromFavorites = function(idPOI){
      console.log("in remove");

        for(let i = 0; i < $scope.pois.length; i++){
            if($scope.pois[i].idPOI == idPOI){
                $scope.pois[i].inFev = false;
            }
        }

      let tmp = $window.localStorage.getItem("favorites" + username);
      let favoritesInLocalStorage = tmp.split(",");

      var index = favoritesInLocalStorage.indexOf(idPOI.toString());
        console.log("removing: "+index);
      if (index > -1) {
          favoritesInLocalStorage.splice(index, 1);
      }

      $window.localStorage.setItem("favorites" + username, favoritesInLocalStorage);
      console.log(favoritesInLocalStorage);
    };

      function contains(a, obj) {
          var i = a.length;
          while (i--) {
              if (a[i] == obj) {
                  return true;
              }
          }
          return false;
      }
  }

})();