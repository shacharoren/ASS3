(function() {
    'use strict';

    tripAdviserApp.factory('PoiService', PoiService);

    PoiService.$inject = ['$http', '$window'];

    function PoiService($http, $window) {

        var serverUrl = 'http://localhost:3000';
        var poiPostfix = '/data/getAllPOI';
        var poiArray = undefined;
        let username = $window.localStorage.getItem("username");

        var login = $window.localStorage.getItem("login");

        //var saved = $window.localStorage.getItem("favorites"+username).split(",");

        loadAllPoi();

        var service = {
            getThreeRandoms: getThreeRandoms,
            getAllPois: getAllPois,
            getRecentlySaved: getRecentlySaved
        };

        return service;

        function getRecentlySaved(){
            var recentlySaved = [];

            return recentlySaved;
        }

        function getThreeRandoms() {
            var tempArray = [];

            if(poiArray){

                var first = getRandomArbitrary(poiArray.length-1);
                var second = getRandomArbitrary(poiArray.length-1);
                var third = getRandomArbitrary(poiArray.length-1);

                tempArray.push(poiArray[first]);
                tempArray.push(poiArray[second]);
                tempArray.push(poiArray[third]);
            }

            return tempArray;
        }

        function getAllPois() {
            let tempArray = [];
            if(poiArray === undefined) {
                return tempArray;
            } else {
                return poiArray;
            }
        }

        function loadAllPoi() {
            $http({
                method: 'GET',
                url: serverUrl + poiPostfix
            })
            .then(function(results) {
                poiArray = results.data;
                let tmp = $window.localStorage.getItem("favorites" + username).split(",");
                for(let i = 0; i < poiArray.length; i++) {
                    if(contains(tmp, poiArray[i].idPOI)){
                        poiArray[i].inFev = true;
                    }else {
                        poiArray[i].inFev = false;
                    }
                }
            })
            .catch(function(err) {
                console.log(err);
            });
        }

        function getRandomArbitrary(max) {
            return Math.floor(Math.random() * max);
        }

        function contains(a, obj) {
            var i = a.length;
            while (i--) {
                if (a[i] == obj) {
                    return true;
                }
            }
            return false;
        }
    }
})();