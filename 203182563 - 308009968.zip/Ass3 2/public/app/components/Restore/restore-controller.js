(function() {
    'use strict';

    tripAdviserApp.controller('RestoreController', RestoreController);

    RestoreController.$inject = ['$scope', '$http'];

    function RestoreController($scope, $http) {
        let serverURL = 'http://localhost:3000/';
        $scope.requiredError = "please fill in missing fields";

        $scope.username = '';
        $scope.answer1 = '';
        $scope.answer2 = '';

        $scope.password = '';

        // get lost password
        $scope.restorePassword = function(){
            var restoreObject = {
                UserName: $scope.username,
                Answer1: $scope.answer1,
                Answer2: $scope.answer2
            };

            let ans = $http({
                method: 'POST',
                url: 'http://localhost:3000/users/restore',
                data: restoreObject
            }).then(function (response){
                $scope.password = response.data['message'];
            }, function (response) {
                console.log("failed");
            })
        }
    }

})();