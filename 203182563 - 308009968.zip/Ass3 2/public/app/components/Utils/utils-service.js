(function() {
    'use strict';

    tripAdviserApp.factory('UtilsService', UtilsService);

    UtilsService.$inject = ['$http', '$window'];

    function UtilsService($http, $window) {

        let serverURL = "http://localhost:3000/";
        let token = undefined;
        let username = undefined;
        let favorites = undefined;
        let poiArray = [];

        let service = {
            setToken: setToken,
            getToken: getToken,
            loginFunction: loginFunction,
            RestoreFunction: RestoreFunction,
            setUsername: setUsername,
            getUsername: getUsername,
            getFavorites: getFavorites,
            loadFavorites: loadFavorites,
            getAllPois: getAllPois,
            isLogin: isLogin,
            setLogin: setLogin,
            getFavCategories: getFavCategories
        };

        return service;

        /////////// Login ///////////

        function isLogin(){
            if(getToken()){
                setLogin(true);
                return true;
            }

            setLogin(false);
            return false;
        }

        function setLogin(bool){
            $window.localStorage.setItem("login", bool);
        }

        function setUsername(usernameb){
            username = usernameb;
            $window.localStorage.setItem("username", usernameb);
            //$window.localStorage.setItem("login", true);

            getFavCategories();
            console.log("in loginnnnn "+ $window.localStorage.getItem("Category1"));
        }

        function getUsername(){
            if(!username){
                //console.log("not username");
                setUsername($window.localStorage.getItem("username"));
                //console.log($window.localStorage.getItem("username"));

            }

            return username;
        }

        function setToken(t) {
            token = t;
            console.log("setting token to be: "+token);
            // SAVE TO LOCAL STORAGE:
            $window.localStorage.setItem("token", token);
            $window.localStorage.setItem("username", username);
            $window.localStorage.setItem("login", true);
        }

        function getToken()
        {
            if(token == undefined){
                //GET FROM LOCAL STORAGE IF undefined
                token = $window.localStorage.getItem("token");
            }

            return token;
        }

        function loginFunction(username, password) {
            var loginObject = {
                UserName: username,
                Password: password
            };
            let ans = $http({
                method: 'POST',
                url: 'http://localhost:3000/users/login',
                data: loginObject
            });
            return ans
        }

        /////////// Favorites ///////////

        function getFavorites() {
            loadFavorites();
            return favorites;
        }

        function loadFavorites(){
            let tmp = [];

            let getFavsObject = {
                UserName: getUsername()
            };

            $http({
                method: 'GET',
                url: 'http://localhost:3000/auto/GetFavoritePOI',
                data: getFavsObject,
                headers: {'x-access-token': getToken()}
            }).then(function (response){
                    for(var i = 0; i < response.data.length; i++){
                        tmp.push(response.data[i]['idPOI']);
                    }
                    favorites = tmp;

            }, function (response) {
                    console.log("fail GET");
                });

        }

        function getAllPois() {
            loadAllPoi();
            let tempArray = [];
            if(poiArray === undefined) {
                return tempArray;
            } else {
                return poiArray;
            }
        }

        function loadAllPoi() {
            var serverUrl = 'http://localhost:3000';
            var poiPostfix = '/data/getAllPOI';
            $http({
                method: 'GET',
                url: serverUrl + poiPostfix
            })
                .then(function(results) {
                    poiArray = results.data;
                })
                .catch(function(err) {
                    console.log(err);
                });
        }

        /////////// Restore ///////////

        function RestoreFunction(username, answer1,answer2) {
            var RestoreObject = {
                UserName: username,
                Answer1: answer1,
                Answer2: answer2
            };

            return $http({
                method: 'GET',
                url: 'http://localhost:3000/users/restore',
                data: RestoreObject
            });
        }

        /////////// Get Users Categories ///////////

         function getFavCategories(){
            // get favorite chosen categories

            let getCatObject = {
                UserName: getUsername()
            };

            $http({
                method: 'GET',
                url: 'http://localhost:3000/auto/GetFavoriteCategories',
                data: getCatObject,
                headers: {'x-access-token': getToken()}
            }).then(function (response){
                let cat1 = response.data[0]['Category1'];
                let cat2 = response.data[0]['Category2'];

                $window.localStorage.setItem("Category1"+username, cat1);
                $window.localStorage.setItem("Category2"+username, cat2);

            }, function (response) {
                console.log("fail GET");
            });
        }
    }

})();